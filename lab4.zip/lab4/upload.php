<html>
<head>
	<meta charset="utf-8">
	<title>File Upload</title>
</head>
<body>
	 
<?php

function displayForms(){
?>
<?php
	if ($_SERVER['REQUEST_METHOD'] == "POST"){
		
		if ((isset($_POST['displayFiles']))
					&& ($_POST['displayFiles'] == "Display")){
						displayRecords();
					}
	}
	?> 
<h1>Please Enter BIO and Upload a Photo </h1>

	
	<form method="POST" enctype="multipart/form-data">
		<input type="hidden" name="formName" value="bioForm">
		<h3>BIO: </h3>
		<textarea name="person_dio" rows="6" cols="50"><?php if(isset($_POST['person_dio'])){ echo $_POST['person_dio']; } ?></textarea>
		<br />
		<h3>Select Photo: </h3>
		<input type="hidden" name="MAX_FILE_SIZE" value="2000000"/>
		<input type="file" name="uploads" />
		<br />
		<input type="submit" name="uploadFiles"  value="Upload"/>
		
	</form>


<?php
}

function validateFormData():array {
	$errMsgs = array();
	$allowed_exts = array("jpg", "png", "gif");
	$allowed_types = array("image/gif", "image/png", "image/jpeg");
	if (isset($_FILES['uploads']) && !empty($_FILES['uploads']['name'])){
		$up =$_FILES['uploads'];
		if ($up['error'] == 0){
			if ($up['size'] == 0){
				$errMsgs[] = "An empty file was uploaded";
			}
			$ext = strtolower(pathinfo($up['name'], PATHINFO_EXTENSION));
			if (!in_array($ext, $allowed_exts)){
				$errMsgs[] = "File extension does not indicate that the uploaded file is of an  allowed file type!";
			}
			if (!in_array($up['type'], $allowed_types)){
				$errMsgs[] = "The uploaded file's MIME type is not allowed!";
			}
			if (!file_exists($up['tmp_name'])){
				$errMsgs[] = "No files exists on the server for this upload!";
			}
			// Do virus scan of file in temporary storage here, if scanner available
		} else {
			$errMsgs[] = "An error occured during file upload!";
		}
	} else {
		$errMsgs[] = "No file was uploaded";
	}

	if(isset($_POST['person_dio'])){
		$uStrings = trim($_POST['person_dio']);
		if (empty($uStrings)){
			
			//If user bio is empty
			$errMsgs[] = "The Bio should not be Empty!";
		}	
	}else {
		$errMsgs[] = "The Bio should not be Empty!";
	}
	
	// If there are other form data items to validate do so here

	return $errMsgs;
}

function processUploads(){
	$status = "OK";
	if(!is_dir('uploads') || !is_writable("uploads")){ 
		$status = "NoDirectory";
	} else {
		$ext = strtolower(pathinfo($_FILES['uploads']['name'], PATHINFO_EXTENSION));
		$filename = $_FILES['uploads']['name'];
		$newName = "uploads/$filename.".rand(10000, 99999) . ".". $ext;
		$success = move_uploaded_file($_FILES['uploads']['tmp_name'], $newName);
		if (!$success){
			$status = "FailMove";
		} else {
			$db_conn = connectDB();
			if (!$db_conn){
				$status = "DBConnectionFail";
			} else {
				$stmt = $db_conn->prepare("insert into lab4 (person_name, person_age,person_dio,file_name, store_file_name,file_uploaded, filesize, file_type) values(?, ?, ?, ?,?, ?, ?, ?)");
				if (!$stmt){
					$status = "PrepareFail";
				} else {
					$my_date = date("Y-m-d H:i:s");
				
					$data = array($_SESSION['user_name'], $_SESSION['user_age'], $_SESSION['person_dio'], $_FILES['uploads']['name'],$newName,$my_date, $_FILES['uploads']['size'], $_FILES['uploads']['type']);
					$result = $stmt->execute($data);
					if(!$result){
						$status = "ExecuteFail";
					}else {
						
						
						echo "<h2>Information Summary<h2>
							<p>Name: " . $_SESSION['user_name'] . "</p>
							<p>Age: " . $_SESSION['user_age'] . "</p>
							<p>Bio: " . $_SESSION['person_dio'] . "</p>
							<p>File Name: " . $_FILES['uploads']['name'] . "</p>
							<p>File Size: " . $_FILES['uploads']['size'] . "</p>
						";
					}
				}
				$db_conn = NULL;
			}
			if ($status != "OK"){
				unlink($newName);
			}
		}
	}
	
	return $status;
}

function displayStatus($status){
	if ($status == "FailMove"){
?>
	<p>File upload failed - failed to move file to permanent storage! </p>
<?php } else if ($status == "NoDirectory"){ ?>
	<p>File upload failed - The permanent storage directory does not exist or is not accessible! </p>
<?php } else if ($status == "PrepareFail"){ ?>
	<p>File upload failed - Error getting ready to insert data into the database! </p>
<?php } else if ($status == "ExecuteFail"){ ?>
	<p>File upload failed - Error insertng data into the database! </p>
<?php } else if ($status == "DBConnectionFail"){ ?>
	<p>File upload failed - Error connecting to the database! </p>
<?php } else { ?>
	<p>File uploaded successfully!</p>
<?php } ?>
	<a href="./index.php">Return to menu</a>
<?php
}

function displayErrors(array $error_msg){
    echo "<p class='errors'>\n";
    foreach($error_msg as $v){
        echo $v."<br>\n";
    }
    echo "</p>\n";
}

?>
</body>
</html>
