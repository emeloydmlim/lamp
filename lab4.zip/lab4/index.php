<?php 
	
	
	//Strict Type Declaration
	declare(strict_types=1);
	session_start();
	require_once("./db_connection.php");
	require_once("./upload.php");
	

?>

<html>
    <head>
        <meta charset="utf-8">
		<title>Registeration From</title>
		<style>
			.errors {
				font-weight: bold;
				color: red;
				font-size: 24px;
			}
		</style>
    </head>
    <body>
        
<?php
if ($_SERVER['REQUEST_METHOD'] == "POST"){
	if(isset($_POST['formName']) && $_POST['formName'] == 'userInfoFrom'){
		$errMsg = checkUserInputs();
		//To count the elements of the array
		if (count($errMsg) >0){
			displayErrors($errMsg);
			step1Form();
		} else {
			if(isset($_POST['user_name'])){
				$_SESSION['user_name']=$_POST['user_name'];
			}
			if(isset($_POST['user_age'])){
				$_SESSION['user_age']=$_POST['user_age'];
			}
			displayForms();
		}
	}elseif(isset($_POST['formName']) && $_POST['formName'] == 'bioForm'){
		$errMsg = validateFormData();
		
		if (count($errMsg) >0){
			displayErrors($errMsg);
			displayForms();
		} else {
			$person_dio = "";
			if(isset($_POST['person_dio'])){
				$_SESSION['person_dio']=$_POST['person_dio'];
			}
			$status = processUploads();
			displayStatus($status);
		}
	}
	
	
	
} else {
	step1Form();
}
// Function Will Validate User Inputs
function checkUserInputs(): array{
	$errMsgs = array();
	
	//Name Inputs data Validation
	if (isset($_POST['user_name'])){
		$uStrings = trim($_POST['user_name']);
		if (!empty($uStrings)){
			if (strlen($uStrings) > 100){
				//If User Input Eceeds the MAximum size of Input Box
				$errMsgs[] = "Maximum Length for Name is 100 Characters!";
			}
		} else {
			//If User Input Contains White space Or Empty Fields
			$errMsgs[] = "The Name field Should not contain white space or empty fields!";
		}
	} 

	//Age Inputs data Validation
	if (isset($_POST['user_age'])){
		$uStrings = trim($_POST['user_age']);
		if (!empty($uStrings)){
			//If User Input Eceeds the MAximum size of Input Box
			if (strlen($uStrings) > 3){
				$errMsgs[] = "Maximum Length for Age is 3 characters!";
			}
		} else {
			//If User Input Contains White space Or Empty Fields
			$errMsgs[] = "The Age field Should not contain white space or empty fields!";
		}
	} 				

	if (count($errMsgs) == 0){
		
	}

	return $errMsgs;
}

//Form Function To Get Data From User 
function step1Form(){
?>
<h1>Registeration From</h1>
	<form id="formA" name="step1" method="POST">
	<input type="hidden" name="formName" value="userInfoFrom">
		<div>
			<label for="user_name">Name: </label>
			<input type="text" id= "user_name" name ="user_name" size="50" value="<?php if(isset($_POST['user_name'])) echo $_POST['user_name']; ?>">
			<br><br>
		</div>
		<div>
			<label for="user_age">Age: </label>
			<input type="text" id= "user_age" name ="user_age" size="50" value="<?php if(isset($_POST['user_age'])) echo $_POST['user_age']; ?>">
			<br><br>
		</div>
		<br />
		<input type="submit"   value="Next"></a>
        
	</form>
<?php
}





?>
    </body>
</html>
