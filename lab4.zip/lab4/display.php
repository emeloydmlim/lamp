<html>
<head>
	<meta charset="utf-8">
	<title>File Upload</title>
</head>
<body>
	


<?php
require_once("db_connection.php");
function displayRecords(){
echo "<h1> Display Data from Database</h1>";

$db_conn = connectDB();
if (!$db_conn){
	echo "<p>Error connecting to the database</p>\n";
} else {
	$stmt = $db_conn->prepare("select person_name, person_age, person_dio,store_file_name,file_uploaded,file_name,file_type from lab4 order by person_name;");
	if (!$stmt){
		echo "<p>Error preparing to read data from the database</p>\n";
	} else {
		$status = $stmt->execute();
		if(!$status){
		echo "<p>Error reading data from the database</p>\n";
		} else {
			if ($stmt->rowCount() > 0){
				echo "<table border=\"1\">\n";
				echo "<tr><th>Name</th><th>Age</th><th>Bio</th><th>Uploaded</th></tr>\n";
				while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					echo "<tr><td>";
					echo $row['person_name'];
					echo "</td><td>";
					echo $row['person_age'];
					echo "</td><td>";
					echo $row['person_dio'];
					echo "</td><td>";
					if (substr($row['file_type'], 0, 5) == "image"){
						echo '<img src = "'.$row['store_file_name'].'" height="400" width="400" />';
					} else {
						echo "<pre>\n";
						echo file_get_contents($row['store_file_name']);
						echo "</pre>\n";
					}
					echo "</td></tr>\n";
				}
				echo "</table>\n<br/><br/>\n";
			}

		}
	}

}
}
displayRecords();

?>
	
</body>
</html>
